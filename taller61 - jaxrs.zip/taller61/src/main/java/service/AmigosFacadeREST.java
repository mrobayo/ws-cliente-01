/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import edu.uees.taller61.Customer;
import java.util.List;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author janito
 */
@Path("amigos")
public class AmigosFacadeREST {
   
    @GET
    @Produces("text/plain")
    public String hola() {
        return "hola amigsos";
    }
    
}
