/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import javax.ws.rs.GET;
import javax.ws.rs.Produces;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;

// The Java class will be hosted at the URI path "/helloworld"
@Path("hello")
public class HelloWorldResource {
    
    // The Java method will process HTTP GET requests
    @GET
    @Produces("text/plain")
    public String message(@QueryParam("q") String q) {
        // Return some cliched textual content
        return "Hello World: " + q;
    }
}
