/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.uees.bsgclient;

import ec.gob.bsg.accesobsgservice.AccesoBSGService;
import ec.gob.bsg.accesobsgservice.BSG04AccederBSG;
import ec.gob.bsg.accesobsgservice.ValidarPermisoPeticion;
import ec.gob.bsg.accesobsgservice.ValidarPermisoRespuesta;
import java.io.StringWriter;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

/**
 * TEST
 */
public class BsgTest {
    
    public static void main(String... args) {      
        try { 
            AccesoBSGService service = new ec.gob.bsg.accesobsgservice.AccesoBSGService();
            BSG04AccederBSG port = service.getBSG04AccederBSGPort();
            
            // WS operation 
            ValidarPermisoPeticion validarPermisoPeticion = new ec.gob.bsg.accesobsgservice.ValidarPermisoPeticion();
            
            validarPermisoPeticion.setCedula("1002003004");
            validarPermisoPeticion.setUrlsw("https://www.bsg.gob.ec/sw/RC/BSGSW01_Consultar_Cedula?wsdl");
            
            // Llamada y Respuesta
            ValidarPermisoRespuesta result = port.validarPermiso(validarPermisoPeticion);
            System.out.println("Result = " + result.getMensaje().getCodError() + " - " + result.getMensaje().getDesError());
            
            System.out.println( xml(result, ValidarPermisoRespuesta.class) );
            
        } catch (Exception e) {
            
        }        
    }
    
    static String xml(Object xmlObject, Class<?> jaxbClass) {
        StringWriter xmlContent = new StringWriter();

        try {
            JAXBContext context = JAXBContext.newInstance(jaxbClass);
            Marshaller m = context.createMarshaller();

            m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
            m.marshal(xmlObject, xmlContent);

        } catch (JAXBException e) {
            e.printStackTrace();
        }

        return xmlContent.toString();
    }
    
}
