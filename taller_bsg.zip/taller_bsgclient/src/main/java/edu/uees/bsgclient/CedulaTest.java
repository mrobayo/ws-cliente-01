/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.uees.bsgclient;

import ec.gob.bsg.accesobsgservice.AccesoBSGService;
import ec.gob.bsg.accesobsgservice.BSG04AccederBSG;
import ec.gob.bsg.accesobsgservice.ValidarPermisoPeticion;
import ec.gob.bsg.accesobsgservice.ValidarPermisoRespuesta;
import ec.gob.registrocivil.consultacedula.Cedula;
import ec.gob.registrocivil.consultacedula.WSRegistroCivilConsultaCedula;
import ec.gob.registrocivil.consultacedula.WSRegistroCivilConsultaCedula_Service;
import static edu.uees.bsgclient.BsgTest.xml;

/**
 * Test Cedula
 */
public class CedulaTest {

    public static WssHeader consultaBsg() {
        WssHeader wssHeader = new WssHeader();
               
        AccesoBSGService service = new ec.gob.bsg.accesobsgservice.AccesoBSGService();
        BSG04AccederBSG port = service.getBSG04AccederBSGPort();

        // WS operation 
        ValidarPermisoPeticion validarPermisoPeticion = new ec.gob.bsg.accesobsgservice.ValidarPermisoPeticion();

        validarPermisoPeticion.setCedula("1002003004");
        validarPermisoPeticion.setUrlsw("https://www.bsg.gob.ec/sw/RC/BSGSW01_Consultar_Cedula?wsdl");

        // Llamada y Respuesta
        ValidarPermisoRespuesta result = port.validarPermiso(validarPermisoPeticion);
        System.out.println("Result = " + result.getMensaje().getCodError() + " - " + result.getMensaje().getDesError());

        wssHeader.setUsername("1002003004");
        wssHeader.setDigest(result.getDigest());
        wssHeader.setExpires(result.getFechaF());
        wssHeader.setFecha(result.getFecha());
        wssHeader.setNonce(result.getNonce());

        System.out.println( xml(result, ValidarPermisoRespuesta.class) );

        
        return wssHeader;
    }
     
   
    public static void consultaCedula(WssHeader wssHeader) {
        try { // Call Web Service Operation
            WSRegistroCivilConsultaCedula_Service service = new ec.gob.registrocivil.consultacedula.WSRegistroCivilConsultaCedula_Service();
         
            // TIP!
            service.setHandlerResolver(new HeaderHandlerResolver(wssHeader));
            WSRegistroCivilConsultaCedula port = service.getWSRegistroCivilConsultaCedulaPort();
            
            
            // WS operation
            String cedula = "0916543210";
            String usuario = "USUARIO";
            String contrasenia = "TEST";
            
            // Llamada WS
            Cedula result = port.busquedaPorCedula(cedula, usuario, contrasenia);
            
            if ("000".equals(result.getCodigoError())) {
                System.out.println("Result = " + result.getNombre());    
            }
            else {
                System.out.println("Error Codigo = " + result.getCodigoError());
            }
            
        } catch (Exception e) {
            // handle custom exceptions here
        }
    }
    
    public static void main(String... args) {
        WssHeader wssHeader = consultaBsg();
        consultaCedula(wssHeader);
    }
    
}
