/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.uees.bsg;

import javax.jws.HandlerChain;
import javax.jws.WebService;

/**
 *
 * @author janito
 */
@WebService(serviceName = "WSRegistroCivilConsultaCedula", portName = "WSRegistroCivilConsultaCedulaPort", endpointInterface = "ec.gob.registrocivil.consultacedula.WSRegistroCivilConsultaCedula", targetNamespace = "http://www.registrocivil.gob.ec/ConsultaCedula", wsdlLocation = "WEB-INF/wsdl/BSGSW01_Consultar_Cedula.wsdl")
@HandlerChain(file = "WSRegistroCivilConsultaCedula_handler.xml")
public class Consultar_Cedula {

    public ec.gob.registrocivil.consultacedula.Cedula busquedaPorCedula(java.lang.String cedula, java.lang.String usuario, java.lang.String contrasenia) {
        ec.gob.registrocivil.consultacedula.Cedula c = new ec.gob.registrocivil.consultacedula.Cedula();
        
        System.out.println("*************** busquedaPorCedula() ***********************");
        
        if (cedula == null || !cedula.matches("[0-9]+")) {
            c.setCodigoError("002");
        }
        else if (cedula.length() != 10) {
            c.setCodigoError("004");
        }
        else {
            c.setCodigoError("000");
            
            c.setCalleDomicilio("AVENIDA DE LA NARANJA 00");
            c.setCedula(cedula);            
            c.setCondicionCedulado("CIUDADANO");
            c.setConyuge(" ");
            c.setDomicilio("BOLIVAR/CALUMA/CALUMA /SAN ANTONIO/");
            c.setError("NO ERROR");
            c.setEstadoCivil("SOLTERO");
            c.setFechaCedulacion("29/09/2015");
            c.setFechaNacimiento("13/05/1947");
            c.setFirmaElectronica("CAMPO POR EL MOMENTO NO DISPONIBLE");
            c.setGenero("MASCULINO");
            c.setIndividualDactilar("E1133I3112");
            c.setInstruccion("BASICA");
            c.setLugarNacimiento("BOLIVAR/CALUMA/CALUMA /SAN ANTONIO/");
            c.setNacionalidad("ECUATORIANA");
            c.setNombreMadre("GARCIA MARIA B");
            c.setNombrePadre("MIGUEZ TOMAS E");
            c.setNombre("MIGUEZ GARCIA PEDRO NELSON");
            c.setNumeroDomicilio("00");
            c.setProfesion("CHOFER PROFESIONAL");
        }
        
        return c;
        //throw new UnsupportedOperationException("Not implemented yet.");
    }

    public ec.gob.registrocivil.consultacedula.Cedula wsUp() {        
        throw new UnsupportedOperationException("Not implemented yet.");
    }
    
}
