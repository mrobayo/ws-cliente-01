/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.uees.bsg;

import ec.gob.bsg.accesobsgservice.MensajeError;
import ec.gob.bsg.accesobsgservice.ValidarPermisoRespuesta;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Calendar;
import java.util.TimeZone;
import javax.jws.WebService;

/**
 *
 * @author janito
 */
@WebService(serviceName = "AccesoBSGService", portName = "BSG04_Acceder_BSGPort", endpointInterface = "ec.gob.bsg.accesobsgservice.BSG04AccederBSG", targetNamespace = "http://bsg.gob.ec/AccesoBSGService", wsdlLocation = "WEB-INF/wsdl/BSGSW08_Acceder_BSG.wsdl")
public class Acceder_BSG {
    
    private static final String CEDULA = "1002003004";
    private static final String URL_SW = "https://www.bsg.gob.ec/sw/RC/BSGSW01_Consultar_Cedula?wsdl";
    
    private static SecureRandom random = null;
    static {
        try {
            random = SecureRandom.getInstance("SHA1PRNG");
        } catch (NoSuchAlgorithmException nsae) {
            nsae.printStackTrace();
        }
    }

    public ValidarPermisoRespuesta validarPermiso(ec.gob.bsg.accesobsgservice.ValidarPermisoPeticion validarPermisoPeticion) {
        String cedula = validarPermisoPeticion.getCedula();
        String urlsw = validarPermisoPeticion.getUrlsw();
        
        MensajeError mensaje = new MensajeError();
        
        ValidarPermisoRespuesta r = new ValidarPermisoRespuesta();
        r.setMensaje(mensaje);
        
        if (!CEDULA.equals(cedula) || !URL_SW.equals(urlsw)) {            
            mensaje.setCodError("001");
            mensaje.setDesError("NO TIENE PERMISO PARA INVOCAR EL SW SOLICITADO");            
        }
        else {
            mensaje.setCodError("000");
            mensaje.setDesError("ACCESO AUTORIZADO");
            
            Calendar fecha = Calendar.getInstance();
            r.setFecha(buildFecha(fecha));
            
            fecha.add(Calendar.SECOND, 60);
            r.setFechaF(buildFecha(fecha));
            
            r.setNonce(buildNonce());
            r.setDigest(buildPasswordDigest(r.getNonce(), r.getFecha(), "XXX"));
        }
        
        return r;
    }
    
    public String buildFecha(Calendar fecha) {
        DateFormat zulu;
        
        zulu = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        zulu.setTimeZone(TimeZone.getTimeZone("UTC"));
        
        return zulu.format(fecha.getTime());
    }

    /**
     * Nonce es un valor random que se incluye en el Token     
     */
    public static String buildNonce(){
        byte[] nonceValue = new byte[16];
        random.nextBytes(nonceValue);
        
        return Base64.getEncoder().encodeToString(nonceValue);
    }
    
    /**
     * Password_Digest = Base64 ( SHA-1 ( nonce + created + password ) )
     */
    public static String buildPasswordDigest(String nonce, String created, String password){
        try {
            byte[] b1 = Base64.getDecoder().decode(nonce);
            byte[] b2 = created.getBytes("UTF-8");
            byte[] b3 = password.getBytes("UTF-8");
            byte[] b4 = new byte[b1.length + b2.length + b3.length];
            int i = 0;
            int count = 0;
            for (i = 0; i < b1.length; i++) {
                b4[count++] = b1[i];
            }
            for (i = 0; i < b2.length; i++) {
                b4[count++] = b2[i];
            }
            for (i = 0; i < b3.length; i++) {
                b4[count++] = b3[i];
            }
            MessageDigest sha = MessageDigest.getInstance("SHA-1");
            sha.reset();
            sha.update(b4);
            
            return Base64.getEncoder().encodeToString(sha.digest());
            
        } catch (Exception e) {
            e.printStackTrace();
            
            return null;
        }   
    }
}
