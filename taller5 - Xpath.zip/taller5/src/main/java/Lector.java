/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.namespace.QName;
import javax.xml.parsers.*;
import javax.xml.xpath.*;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

/**
 * Extraer informacion de un XML
 */
public class Lector {
    
    Document xmlDocument;
    XPath xPath;
    
    public Lector(String archivo) {
        try {
            xmlDocument = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(archivo);
            xPath = XPathFactory.newInstance().newXPath();
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }
    
    public Object extraer(String expresion, QName returnType) {
        try {
            XPathExpression xPathExpression = xPath.compile(expresion);
            return xPathExpression.evaluate(xmlDocument, returnType);
            
        } catch (XPathExpressionException ex) {
            Logger.getLogger(Lector.class.getName()).log(Level.SEVERE, null, ex);
	}
        return null;
    }
    
    public static void main(String... args) {        
        Lector lector = new Lector("ejercicio\\FACTURA_1601201501_09927159870011_001002000000005_0000000019.xml");
        String r = (String) lector.extraer("//ambiente", XPathConstants.STRING);
        System.out.println("RESULTADO: " + r);
    }
    
}
