/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import javax.xml.parsers.DocumentBuilderFactory;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.namespace.QName;
import javax.xml.xpath.*;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;


/**
 *
 * @author
 */
public class LectorDdp {
    Document xmlDocument;
    XPath xPath;
    
    public LectorDdp(String archivo) {
        try {
            xmlDocument = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(archivo);
            xPath = XPathFactory.newInstance().newXPath();
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }
    
    public Object extraer(String expresion, QName returnType) {
        try {
            XPathExpression xPathExpression = xPath.compile(expresion);
            return xPathExpression.evaluate(xmlDocument, returnType);
            
        } catch (XPathExpressionException ex) {
            Logger.getLogger(Lector.class.getName()).log(Level.SEVERE, null, ex);
	}
        return null;
    }
    
    public static void main(String... args) {        
        Lector lector = new Lector("ejercicio\\DDP.Full.238-846.xml");
        Double r = (Double) lector.extraer("count(//ContractingGovernment[@lritID])", XPathConstants.NUMBER);
        
        if (r > 0) {        
            NodeList list = (NodeList) lector.extraer("//ContractingGovernment/@lritID", XPathConstants.NODESET);        
            
            for(int i=0; i<list.getLength(); i++) {
                Object n = list.item(i);
                System.out.println("RESULTADO: " + n);
            }
            
        }
        
        Object a = lector.extraer("//ContractingGovernment[@lritID=1004]/Name", XPathConstants.STRING);
        System.out.println("RES = " + a);
        
    }
}
