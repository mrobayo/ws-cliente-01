/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package taller42.test;

import edu.uees.taller42.EjemploFactura;
import edu.uees.taller42.XmlUtil;
import generated.Factura;
import java.io.File;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Taller 4q
 * 
 */
public class ProcesarXml {
    
    String ruta = "sri\\ejemplos\\FACTURA_1601201501_09927159870011_001002000000005_0000000019.xml";
    
    @Test
    public void leerXml() throws Exception {
        File archivo = new File(ruta);        
        Factura factura = XmlUtil.unmarshalFactura(archivo);        
        
        System.out.println(factura.toString());
    }
   
    @Test
    public void guardarXml() throws Exception {
        File archivo = new File("sri\\ejemplos\\EJEMPLO.xml");
        
        Factura factura = EjemploFactura.ejemplo();
        XmlUtil.marshalFactura(factura, archivo);
        
        String error = XmlUtil.validar(archivo);
        System.out.println(error);        
        
    }
    
}
