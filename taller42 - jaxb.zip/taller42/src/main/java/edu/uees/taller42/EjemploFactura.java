/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.uees.taller42;

import generated.Factura;
import generated.Impuesto;
import generated.InfoTributaria;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Ejemplo de una Factura
 */
public class EjemploFactura {
   
    /**
     * Ejemplo 
     */
    public static Factura ejemplo() {
        Factura factura = new Factura();
        factura.setId("comprobante");
        factura.setVersion("1.1.0");
        
        factura.setInfoFactura(infoFactura());
        factura.setInfoTributaria(infoTributaria());
        factura.setInfoAdicional(infoAdicional());
        factura.setDetalles(detalles());
        
        return factura;
    }
    
    private static InfoTributaria infoTributaria() {
        InfoTributaria i = new InfoTributaria();
        
        i.setAmbiente("1");    // PRUEBAS
        i.setTipoEmision("1"); // NORMAL

        i.setRazonSocial("RAZON SOCIAL");
        i.setNombreComercial("NOMBRE COMERCIAL");
        i.setRuc("0916656550001");
        i.setDirMatriz("MATRIZ");

        i.setCodDoc("01");
        i.setEstab("001");
        i.setPtoEmi("001");
        i.setSecuencial("0000001");
        
        i.setClaveAcceso(claveAcceso(new Date(), i.getCodDoc(), i.getRuc(), i.getAmbiente(), i.getEstab()+i.getPtoEmi(), i.getSecuencial(), i.getTipoEmision()));
        
        return i;
    }
    
    private static Factura.InfoFactura infoFactura() {
        Factura.InfoFactura a = new Factura.InfoFactura();
        a.setMoneda("DOLAR");
        a.setFechaEmision("31/08/2016");

        a.setDirEstablecimiento("DIRECCION ESTABLECIMIENTO");
        a.setObligadoContabilidad("SI");
        
        a.setRazonSocialComprador("CONSUMIDOR FINAL");
        a.setTipoIdentificacionComprador("04");
        a.setIdentificacionComprador("9999999999999");
                        
        a.setPropina(BigDecimal.ZERO);
        a.setImporteTotal(BigDecimal.ZERO);
        a.setTotalSinImpuestos(BigDecimal.ZERO);
        a.setTotalDescuento(BigDecimal.ZERO);
        a.setTotalConImpuestos(new Factura.InfoFactura.TotalConImpuestos());
                
        Factura.InfoFactura.TotalConImpuestos.TotalImpuesto i = new Factura.InfoFactura.TotalConImpuestos.TotalImpuesto();
        i.setCodigo("2");
        i.setCodigoPorcentaje("0");
        i.setTarifa(BigDecimal.ZERO);        
        i.setValor(BigDecimal.ZERO);        
        i.setBaseImponible(BigDecimal.ONE);
        
        a.getTotalConImpuestos().getTotalImpuesto().add(i);
        
        return a;
    }

    private static String claveAcceso(Date fecha, String tipo, String rucSujeto, String ambiente, String serie, String secuencial, String emision) {
        StringBuilder clave = new StringBuilder();
        
        SimpleDateFormat ddmmyyyy = new SimpleDateFormat("ddMMyyyy");

        clave.append(ddmmyyyy.format(fecha));    // 8
        clave.append(tipo);       // 2
        clave.append(rucSujeto);          //13
        clave.append(ambiente);   // 1
        clave.append(serie);              // 6
        clave.append(secuencial);         // 9
        clave.append("00000000");     // 8
        clave.append(emision);    // 1

        String cadena = clave.toString();
        final int digitoVerificador = modulo11(cadena);

        cadena = clave.append(digitoVerificador).toString();
        return cadena;
    }    
    
    private static int modulo11(final String cadena) {
	int pivote = 2;
	final String invertida = invertirCadena(cadena);
        int longitudCadena = invertida.length();

        int cantidadTotal = 0;
        int b = 1;

        for (int i = 0; i < longitudCadena; i++) {
            if (pivote == 8) {
                pivote = 2;
            }
            int temporal = Integer.parseInt("" + invertida.substring(i, b));
            b++;
            temporal *= pivote;
            pivote++;
            cantidadTotal += temporal;
        }
        cantidadTotal = 11 - cantidadTotal % 11;

        switch (cantidadTotal) {
        	case 10:
        		cantidadTotal = 1;
        		break;
        	case 11:
        		cantidadTotal = 0;
        		break;
        }

        return cantidadTotal;
    }

    private static String invertirCadena(final String cadena) {
        String cadenaInvertida = "";
        for (int x = cadena.length() - 1; x >= 0; x--) {
            cadenaInvertida = cadenaInvertida + cadena.charAt(x);
        }
        return cadenaInvertida;
    }

    private static Factura.InfoAdicional infoAdicional() {
        Factura.InfoAdicional i = new Factura.InfoAdicional();
        return i;
    }

    private static Factura.Detalles detalles() {        
        Factura.Detalles.Detalle d = new Factura.Detalles.Detalle();
        Impuesto i = new Impuesto();           
        
        i.setCodigo("0");
	i.setCodigoPorcentaje("0");
	i.setTarifa(BigDecimal.ZERO);
	i.setBaseImponible(BigDecimal.ONE);
	i.setValor(BigDecimal.ZERO);
        
        Factura.Detalles.Detalle.Impuestos impuestos = new Factura.Detalles.Detalle.Impuestos();        
	impuestos.getImpuesto().add(i);
                
        d.setCodigoPrincipal("1");
	d.setDescripcion("LINEA 1");
	d.setCantidad(BigDecimal.ONE);
	d.setPrecioUnitario(BigDecimal.ONE);
	d.setDescuento(BigDecimal.ZERO);
	d.setPrecioTotalSinImpuesto(BigDecimal.ONE);
        d.setImpuestos(impuestos);
        
        Factura.Detalles detalles = new Factura.Detalles();
        detalles.getDetalle().add(d);
        
        return detalles;
    }
    
}
