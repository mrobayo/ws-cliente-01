/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.uees.taller42;

import generated.Factura;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.SchemaFactory;
import org.xml.sax.SAXException;

/**
 *
 * @author janito
 */
public class XmlUtil {
    
    static String xsd = "sri\\schemas\\v1.0.0\\factura_v1.0.0.xsd";
    
    /**
     * Lee un documento XML
     */
    public static Factura unmarshalFactura(File archivo) throws UnsupportedEncodingException, FileNotFoundException {
        Factura item = null;
        
        try {
            JAXBContext context = JAXBContext.newInstance(Factura.class);
            Unmarshaller unmarshaller = context.createUnmarshaller();
            
            item = (Factura) unmarshaller.unmarshal(new InputStreamReader(new FileInputStream(archivo), "UTF-8"));
            
        } catch (JAXBException ex) {
            Logger.getLogger(XmlUtil.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return item;
    }
    
    /**
     * Guardar un documento XML
     */
    public static void marshalFactura(Factura factura, File archivo) {
        try {
            JAXBContext context = JAXBContext.newInstance(Factura.class);
            Marshaller m = context.createMarshaller();

            m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
            m.marshal(factura, archivo);

	} catch (JAXBException ex) {
            Logger.getLogger(XmlUtil.class.getName()).log(Level.SEVERE, null, ex);
	}
    }

    /**
     * Validar documento XML
     */
    public static String validar(File archivoXML) {
        String mensaje = null;
	SchemaFactory schemaFactory = SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema");
        
	javax.xml.validation.Schema schema;
	try {
            schema = schemaFactory.newSchema(new File(xsd));
            
	} catch (SAXException e) {
            throw new IllegalStateException("Existe un error en la sintaxis del esquema", e);
	}
	javax.xml.validation.Validator validator = schema.newValidator();
	try {
            validator.validate(new StreamSource(archivoXML));
            
	} catch (Exception e) {
            return e.getMessage();
	}
	return mensaje;
    }
    
}
